@extends('layouts.app')

@section('titre', 'Gestion des Symptômes')

@section('content')
<div class="container mt-4">
    <div class="row">

        <!-- Bouton Ajouter -->
        <div class="d-flex justify-content-end mb-3">
            <button class="btn btn-sm btn-primary" id="btnAdd">
                <i class="fa fa-plus me-1"></i> Ajouter
            </button>
        </div>

        <!-- Sidebar -->
        @include('layouts.partials.configside')

        <!-- Contenu -->
        <div class="col-xl-9 col-lg-8">
            <div class="block block-rounded">
                <div class="block-header block-header-default">
                    <h3 class="block-title">Liste des Symptômes</h3>
                </div>

                <div class="block-content block-content-full">
                    <div class="table-responsive">
                        <table id="symptomeTable" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Nom</th>
                                    <th>Description</th>
                                    <th class="col-3">Actions</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- MODAL -->
<div class="modal fade" id="crudModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">Ajouter un symptôme</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <form id="crudForm">
                    @csrf
                    <input type="hidden" name="id" id="id">

                    <div class="mb-3">
                        <label class="form-label">Nom du symptôme</label>
                        <input type="text" name="nom" id="nom" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" id="description" class="form-control"></textarea>
                    </div>

                    <div class="text-end border-top pt-3">
                        <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">
                            Fermer
                        </button>
                        <button type="submit" class="btn btn-sm btn-primary" id="btnSave">
                            Enregistrer
                        </button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
@endsection


@section('scripts')
<script>
$(document).ready(function() {

    let table = $('#symptomeTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: "{{ route('symptomes.index') }}",
        columns: [
            { data: 'nom', name: 'nom' },
            { data: 'description', name: 'description' },
            { data: 'actions', name: 'actions', orderable: false, searchable: false }
        ]
    });

    // Ouvrir modal ajout
    $('#btnAdd').click(function() {
        $('#crudForm')[0].reset();
        $('#id').val('');
        $('#modalTitle').text('Ajouter un symptôme');
        $('#crudModal').modal('show');
    });

    // SUBMIT (create + update)
    $('#crudForm').submit(function(e) {
        e.preventDefault();

        let id = $('#id').val();
        let url = id ? '/symptomes/' + id : '/symptomes';
        let method = id ? 'PUT' : 'POST';

        $.ajax({
            url: url,
            method: method,
            data: $(this).serialize(),
            success: function(res) {
                $('#crudModal').modal('hide');
                table.ajax.reload();
            },
            error: function(err) {
                console.log(err);
                alert('Erreur...');
            }
        });
    });

    // EDIT
    $('#symptomeTable').on('click', '.edit', function() {
        let id = $(this).data('id');

        $.get('/symptomes/' + id + '/edit', function(data) {
            $('#modalTitle').text('Modifier le symptôme');
            $('#id').val(data.id);
            $('#nom').val(data.nom);
            $('#description').val(data.description);
            $('#crudModal').modal('show');
        });
    });

    // DELETE
    $('#symptomeTable').on('click', '.delete', function() {
        let id = $(this).data('id');

        if(confirm('Supprimer ce symptôme ?')) {
            $.ajax({
                url: '/symptomes/' + id,
                method: 'DELETE',
                data: {
                    _token: "{{ csrf_token() }}"
                },
                success: function() {
                    table.ajax.reload();
                }
            });
        }
    });

    // RESET MODAL
    $('#crudModal').on('hidden.bs.modal', function () {
        $('#crudForm')[0].reset();
        $('#id').val('');
    });

});
</script>
@endsection