<?php
namespace App\Http\Controllers;

use App\Models\Commande;
use App\Models\Consultation;
use App\Models\Examen;
use App\Models\Fournisseur;
use App\Models\Hospitalisation;
use App\Models\Lit;
use App\Models\Medicament;
use App\Models\Paiement;
use App\Models\Patient;
use App\Models\RendezVous;
use App\Models\Salle;
use App\Models\User;
use App\Models\Ordonnance;

use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        if ($user->hasRole('super_admin') || $user->hasRole('superadmin')) {
            return $this->superadminDashboard();
        } elseif ($user->hasRole('admin')) {
            return $this->adminDashboard();
        } elseif ($user->hasRole('secretaire')) {
            return $this->secretaireDashboard();
        } elseif ($user->hasRole('medecin')) {
            return $this->medecinDashboard();
        } elseif ($user->hasRole('client')) {
            return $this->clientDashboard();
        } else {
            return $this->defaultDashboard();
        }
    }

    private function superadminDashboard()
    {
        $year = session('exercice_year', date('Y'));

        // ── Stats globales via DB::table() (pas de surcharge Eloquent) ──
        $stats = [
            'total_users'         => DB::table('users')->count(),
            'total_medecins'      => DB::table('users')->join('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')->join('roles', 'model_has_roles.role_id', '=', 'roles.id')->where('roles.name', 'medecin')->count(),
            'total_secretaires'   => DB::table('users')->join('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')->join('roles', 'model_has_roles.role_id', '=', 'roles.id')->where('roles.name', 'secretaire')->count(),
            'total_admins'        => DB::table('users')->join('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')->join('roles', 'model_has_roles.role_id', '=', 'roles.id')->where('roles.name', 'admin')->count(),
            'total_patients'      => DB::table('patients')->whereYear('created_at', $year)->count(),
            'total_ordonnance'    => DB::table('ordonnances')->whereYear('created_at', $year)->count(),
            'total_fournisseur'   => DB::table('fournisseurs')->count(),
            'total_rendezvou'     => DB::table('rendezvous')->whereYear('created_at', $year)->count(),
            'total_ticket'        => DB::table('tickets')->whereYear('created_at', $year)->count(),
            'total_medicament'    => DB::table('medicaments')->count(),
            'total_examens'       => DB::table('examens')->count(),
            'total_lits'          => DB::table('lits')->count(),
            'new_patients_today'  => DB::table('patients')->whereDate('created_at', today())->count(),
            'total_consultations' => DB::table('consultations')->whereYear('created_at', $year)->count(),
        ];

        // ── Graphique 7 jours : 3 requêtes GROUP BY au lieu de 21 ─────
        $startDate = now()->subDays(6)->startOfDay();

        // Patients par jour
        $patientsPerDay = Patient::selectRaw('DATE(created_at) as date, COUNT(*) as total')
            ->where('created_at', '>=', $startDate)
            ->groupByRaw('DATE(created_at)')
            ->get()->keyBy('date');

        // Consultations par jour
        $consultationsPerDay = Consultation::selectRaw('DATE(created_at) as date, COUNT(*) as total')
            ->where('created_at', '>=', $startDate)
            ->groupByRaw('DATE(created_at)')
            ->get()->keyBy('date');

        // Rendez-vous par jour
        $rdvPerDay = RendezVous::selectRaw('DATE(created_at) as date, COUNT(*) as total')
            ->where('created_at', '>=', $startDate)
            ->groupByRaw('DATE(created_at)')
            ->get()->keyBy('date');

        // Construction du tableau final
        $last7Days = collect();
        for ($i = 6; $i >= 0; $i--) {
            $date = now()->subDays($i)->format('Y-m-d');
            $last7Days->push([
                'date'          => $date,
                'patients'      => $patientsPerDay[$date]->total      ?? 0,
                'consultations' => $consultationsPerDay[$date]->total  ?? 0,
                'rendezvous'    => $rdvPerDay[$date]->total            ?? 0,
            ]);
        }

        return view('dashboard', compact('stats', 'last7Days'));
    }


    private function adminDashboard()
    {
        $year = session('exercice_year', date('Y'));
        $stats = [
            'total_personnel'    => DB::table('users')->join('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')->join('roles', 'model_has_roles.role_id', '=', 'roles.id')->whereIn('roles.name', ['medecin', 'secretaire'])->count(),
            'consultations_mois' => DB::table('consultations')->whereYear('created_at', $year)->whereMonth('created_at', now()->month)->count(),
            'revenus_mois'       => DB::table('paiements')->whereYear('created_at', $year)->whereMonth('created_at', now()->month)->sum('montant_total'),
            'alertes_stock'      => DB::table('medicaments')->whereColumn('stock', '<=', 'stock_min')->count(),
            'total_patients'     => DB::table('patients')->whereYear('created_at', $year)->count(),
            'new_patients_today' => DB::table('patients')->whereYear('created_at', $year)->whereDate('created_at', today())->count(),
        ];

        $lowStockMedicaments = DB::table('medicaments')
            ->whereColumn('stock', '<=', 'stock_min')
            ->orderBy('stock')
            ->limit(5)
            ->get(['nom', 'stock', 'stock_min']);

        return view('dashboard', compact('stats', 'lowStockMedicaments'));
    }

    private function secretaireDashboard()
    {
        $todayAppointments = RendezVous::with(['patient', 'medecin'])
            ->whereDate('date_heure', today())
            ->orderBy('date_heure')
            ->get();

        $stats = [
            'new_patients_today' => DB::table('patients')->whereDate('created_at', today())->count(),
            'rdv_realises'       => DB::table('rendezvous')->whereDate('date_heure', today())->where('statut', 'realise')->count(),
            'rdv_attente'        => DB::table('rendezvous')->whereDate('date_heure', today())->where('statut', 'prevu')->count(),
            'total_patients'     => DB::table('patients')->count(),
        ];

        return view('dashboard', compact('todayAppointments', 'stats'));
    }

    private function medecinDashboard()
    {
        $medecinId = Auth::id();

        $stats = [
            'consultations_today'     => DB::table('consultations')->where('medecin_id', $medecinId)->whereDate('created_at', today())->count(),
            'total_patients'          => DB::table('patients')->count(),
            'total_consultations'     => DB::table('consultations')->where('medecin_id', $medecinId)->count(),
            'total_hospitalisations'  => DB::table('hospitalisations')->count(),
            'new_patients_today'      => DB::table('patients')->whereDate('created_at', today())->count(),
            'active_hospitalisations' => DB::table('hospitalisations')->where('etat', 'en cours')->count(),
        ];

        $todayAppointments = RendezVous::with('patient')
            ->where('medecin_id', $medecinId)
            ->whereDate('date_heure', today())
            ->orderBy('date_heure')
            ->get();

        $activeHospitalisations = Hospitalisation::with(['consultation.patient', 'salle', 'service'])
            ->where('etat', 'en cours')
            ->get();

        $consultationStats = $this->getConsultationStats();

        return view('dashboard', compact(
            'stats',
            'todayAppointments',
            'activeHospitalisations',
            'consultationStats'
        ));
    }

    private function clientDashboard()
    {
        $user = Auth::user();
        $patientId = $user->patient->id ?? null;

        $data = [
            'mesRendezVous' => collect(),
            'derniereConsultation' => null,
            'ordonnancesActives' => collect(),
        ];

        if ($patientId) {
            $data['mesRendezVous'] = RendezVous::with('medecin')
                ->where('patient_id', $patientId)
                ->where('date_heure', '>=', now())
                ->orderBy('date_heure')
                ->get();

            $data['derniereConsultation'] = Consultation::where('patient_id', $patientId)
                ->latest()
                ->first();

            $data['ordonnancesActives'] = Ordonnance::where('patient_id', $patientId)
                ->where('est_active', true)
                ->get();
        }

        return view('dashboard', $data);
    }

    private function defaultDashboard()
    {
        $user = Auth::user();

        // Tableau de bord spécifique pour le pharmacien
        if ($user->hasRole('pharmacien')) {
            $stats = [
                // Statistiques principales pour le pharmacien
                'total_ordonnances' => Ordonnance::count(),
                'ordonnances_today' => Ordonnance::whereDate('created_at', today())->count(),
                'ordonnances_pending' => Ordonnance::where('statutordo', 'impaye')->count(),
                'ordonnances_processed' => Ordonnance::where('statutordo', 'paye')->count(),

                // Gestion du stock
                'total_medicaments' => Medicament::count(),
                'medicaments_low_stock' => Medicament::where('stock', '<=', 10)->where('stock', '>', 0)->count(),
                'medicaments_out_of_stock' => Medicament::where('stock', '<=', 0)->count(),
//                'medicaments_expiring_soon' => Medicament::whereDate('date_expiration', '<=', now()->addDays(30))->count(),

                // Fournisseurs et approvisionnement
                'total_fournisseurs' => Fournisseur::count(),
                'commandes_pending' => Commande::where('statut', 'en_attente')->count(),


                // Patients et consultations liées
                'total_patients' => Patient::count(),
                'patients_today' => Patient::whereDate('created_at', today())->count(),

                // Hospitalisation et lits
                'total_lits' => Lit::count(),
                'lits_occupes' => Lit::where('statut', 'occupé')->count(),
                'patients_hospitalises' => Hospitalisation::where('etat', 'en cours')->count(),

                // Tickets et file d'attente
                'total_tickets' => \App\Models\Ticket::count(),
                'tickets_today' => \App\Models\Ticket::whereDate('created_at', today())->count(),

                // Paiements et finances
                'paiements_today' => Paiement::whereDate('created_at', today())->sum('montant_total'),
                'paiements_pending' => Paiement::where('statut', 'en_attente')->count(),
            ];

            // Données pour les graphiques
            $charts = [
                'ordonnances_monthly' => $this->getOrdonnancesMonthly(),
                'medicaments_stock' => $this->getMedicamentsStockStats(),
                'top_medicaments' => $this->getTopMedicaments(),
            ];

            return view('dashboard', compact('stats', 'charts'));
        }

        // Tableau de bord par défaut pour les autres rôles
        $stats = [
            'total_patients'           => DB::table('patients')->count(),
            'total_consultations'      => DB::table('consultations')->count(),
            'total_ordonnances'        => DB::table('ordonnances')->count(),
            'ordonnances_today'        => DB::table('ordonnances')->whereDate('created_at', today())->count(),
            'ordonnances_pending'      => DB::table('ordonnances')->where('statutordo', 'impaye')->count(),
            'ordonnances_processed'    => DB::table('ordonnances')->where('statutordo', 'paye')->count(),
            'total_medecins'           => DB::table('users')->join('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')->join('roles', 'model_has_roles.role_id', '=', 'roles.id')->where('roles.name', 'medecin')->count(),
            'total_rendezvous'         => DB::table('rendezvous')->count(),
            'total_medicaments'        => DB::table('medicaments')->count(),
            'medicaments_low_stock'    => DB::table('medicaments')->where('stock', '<=', 10)->where('stock', '>', 0)->count(),
            'medicaments_out_of_stock' => DB::table('medicaments')->where('stock', '<=', 0)->count(),
            'total_fournisseurs'       => DB::table('fournisseurs')->count(),
            'patients_today'           => DB::table('patients')->whereDate('created_at', today())->count(),
            'total_lits'               => DB::table('lits')->count(),
            'lits_occupes'             => DB::table('lits')->where('statut', 'occupé')->count(),
            'total_tickets'            => DB::table('tickets')->count(),
        ];

        return view('dashboard', compact('stats'));
    }

// Méthodes helper pour les données des graphiques
    private function getOrdonnancesMonthly()
    {
        return Ordonnance::selectRaw('MONTH(created_at) as month, COUNT(*) as count')
            ->whereYear('created_at', date('Y'))
            ->groupBy('month')
            ->orderBy('month')
            ->get()
            ->pluck('count', 'month');
    }

    private function getMedicamentsStockStats()
    {
        return [
            'normal' => Medicament::where('stock', '>', 10)->count(),
            'low' => Medicament::whereBetween('stock', [1, 10])->count(),
            'out' => Medicament::where('stock', 0)->count(),
        ];
    }

    private function getTopMedicaments()
    {
        return Medicament::orderBy('stock', 'asc')
            ->take(10)
            ->get(['nom', 'stock', 'stock_min']);
    }

    private function getConsultationStats()
    {
        // 1 seule requête GROUP BY au lieu de 6 requêtes en boucle
        $results = Consultation::selectRaw(
                'YEAR(date_consultation) as yr, MONTH(date_consultation) as mo, COUNT(*) as total'
            )
            ->where('date_consultation', '>=', Carbon::now()->subMonths(5)->startOfMonth())
            ->groupByRaw('YEAR(date_consultation), MONTH(date_consultation)')
            ->orderByRaw('yr ASC, mo ASC')
            ->get()
            ->keyBy(fn($r) => $r->yr . '-' . str_pad($r->mo, 2, '0', STR_PAD_LEFT));

        $months = [];
        $counts = [];

        for ($i = 5; $i >= 0; $i--) {
            $month     = Carbon::now()->subMonths($i);
            $key       = $month->format('Y-m');
            $months[]  = $month->format('M Y');
            $counts[]  = $results[$key]->total ?? 0;
        }

        return ['months' => $months, 'counts' => $counts];
    }
}
