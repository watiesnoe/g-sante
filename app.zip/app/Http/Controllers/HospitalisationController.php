<?php

namespace App\Http\Controllers;

use App\Models\Hospitalisation;
use App\Models\Paiement;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Yajra\DataTables\DataTables;

class HospitalisationController extends Controller

{
    /**
     * Display a listing of the resource.
     */
 public function index(Request $request)
{
    abort_unless(Auth::user()->can('hospitalisations.view'), 403, 'Accès non autorisé : vous n\'avez pas la permission de voir les hospitalisations.');

    if ($request->ajax()) {
        $year = session('exercice_year', date('Y'));
        $hospitalisations = Hospitalisation::with([
            'consultation.patient',
            'salle',
            'lit',
            'service'
        ])
            ->whereYear('created_at', $year)
            ->where('etat', 'en cours') // 🔹 Filtre ajouté ici
            ->latest();

        return DataTables::of($hospitalisations)
            ->addColumn('patient', function ($row) {
                return ($row->consultation->patient->nom ?? $row->patient->nom ?? '-') . ' ' .
                    ($row->consultation->patient->prenom ?? $row->patient->prenom ?? '-');
            })
            ->addColumn('salle_lit', function ($row) {
                return ($row->salle->nom ?? '-') . '/' . ($row->lit->numero ?? '-');
            })
            ->addColumn('date_entree', function ($row) {
                return \Carbon\Carbon::parse($row->date_entree)->format('d-m-Y');
            })
            ->addColumn('etat', function ($row) {
                $class = match ($row->etat) {
                    'en_cours', 'en cours' => 'bg-warning', // 💡 Petit conseil : j'ai ajouté 'en cours' avec espace au cas où
                    'terminee' => 'bg-success',
                    default => 'bg-secondary',
                };
                return '<span class="badge ' . $class . '">' . ucfirst($row->etat) . '</span>';
            })
            ->addColumn('action', function ($row) {
                $user = Auth::user();
                $html = '';

                if ($user->can('hospitalisations.view')) {
                    $html .= '<a href="' . route('hospitalisations.show', $row->uuid) . '" class="btn btn-sm btn-outline-primary" title="Voir"><i class="fa fa-eye"></i></a>';
                }
                if ($user->can('hospitalisations.pdf')) {
                    $html .= '<a href="' . route('hospitalisations.pdf', $row->uuid) . '" target="_blank" class="btn btn-sm btn-outline-warning" title="Imprimer"><i class="fa fa-print"></i></a>';
                }
                if ($user->can('hospitalisations.edit')) {
                    $html .= '<a href="' . route('hospitalisations.edit', $row->uuid) . '" class="btn btn-sm btn-outline-info" title="Modifier"><i class="fa fa-pencil-alt"></i></a>';
                }
                if ($user->can('hospitalisations.paiement')) {
                    $html .= '<button type="button" class="btn btn-sm btn-outline-success btn-paiement" data-id="' . $row->uuid . '" data-date="' . $row->date_entree . '" data-montant="' . ($row->prix_jour ?? 0) . '" title="Paiement"><i class="fa fa-credit-card"></i></button>';
                }
                if ($user->can('transferts.create')) {
                    $patientUuid = $row->consultation->patient->uuid ?? '';
                    $consultationUuid = $row->consultation->uuid ?? '';
                    $hospitalisationUuid = $row->uuid ?? '';
                    $html .= '<button type="button" class="btn btn-sm btn-outline-success" onclick="openTransfertModal(\'' . $patientUuid . '\', \'' . $consultationUuid . '\', \'' . $hospitalisationUuid . '\')" title="Transférer"><i class="fa fa-exchange-alt"></i></button>';
                }
                if ($user->can('hospitalisations.delete')) {
                    $html .= '<form action="' . route('hospitalisations.destroy', $row->uuid) . '" method="POST" class="d-inline" onsubmit="return confirm(\'Supprimer cette hospitalisation ?\')">'. csrf_field() . method_field('DELETE') . '<button type="submit" class="btn btn-sm btn-outline-danger" title="Supprimer"><i class="fa fa-trash"></i></button></form>';
                }

                return '<div class="d-flex align-items-center justify-content-center gap-1">' . $html . '</div>';
            }) //  Correction : Fermeture correcte de la colonne 'action'
            ->rawColumns(['etat', 'action'])
            ->make(true);
    }

    return view('application.hospitalisation.index');
}

   public function hopialisationrealise(Request $request)
{
    abort_unless(Auth::user()->can('hospitalisations.view'), 403, 'Accès non autorisé : vous n\'avez pas la permission de voir les hospitalisations.');

    if ($request->ajax()) {
        $year = session('exercice_year', date('Y'));
        $hospitalisations = Hospitalisation::with([
            'consultation.patient',
            'salle',
            'lit',
            'service'
        ])
            ->whereYear('created_at', $year)
            ->where('etat', 'terminé') // 🔹 Filtre des hospitalisations terminées
            ->get();

        return DataTables::of($hospitalisations)
            ->addColumn('patient', function ($row) {
                return ($row->consultation->patient->nom ?? $row->patient->nom ?? '-') . ' ' .
                    ($row->consultation->patient->prenom ?? $row->patient->prenom ?? '-');
            })
            ->addColumn('salle_lit', function ($row) {
                return ($row->salle->nom ?? '-') . '/' . ($row->lit->numero ?? '-');
            })
            ->addColumn('date_entree', function ($row) {
                return \Carbon\Carbon::parse($row->date_entree)->format('d-m-Y');
            })
            ->addColumn('etat', function ($row) {
                $class = match ($row->etat) {
                    'en_cours', 'en cours' => 'bg-warning',
                    'terminee', 'terminé', 'termine' => 'bg-success', // 💡 Gère les variantes d'écriture pour le vert
                    default => 'bg-secondary',
                };
                return '<span class="badge ' . $class . '">' . ucfirst($row->etat) . '</span>';
            })
            ->addColumn('action', function ($row) {
                $user = Auth::user();
                $html = '';

                if ($user->can('hospitalisations.view')) {
                    $html .= '<a href="' . route('hospitalisations.show', $row->uuid) . '" class="btn btn-sm btn-outline-primary" title="Voir"><i class="fa fa-eye"></i></a>';
                }
                if ($user->can('hospitalisations.pdf')) {
                    $html .= '<a href="' . route('hospitalisations.pdf', $row->uuid) . '" target="_blank" class="btn btn-sm btn-outline-warning" title="Imprimer"><i class="fa fa-print"></i></a>';
                }
                if ($user->can('hospitalisations.edit')) {
                    $html .= '<a href="' . route('hospitalisations.edit', $row->uuid) . '" class="btn btn-sm btn-outline-info" title="Modifier"><i class="fa fa-pencil-alt"></i></a>';
                }
                if ($user->can('transferts.create')) {
                    $html .= '<button type="button" class="btn btn-sm btn-outline-success" onclick="openTransfertModal('.($row->consultation->patient_id ?? $row->patient_id).', '.($row->consultation_id ?? "''").', '.$row->id.')" title="Transférer"><i class="fa fa-exchange-alt"></i></button>';
                }
                if ($user->can('hospitalisations.delete')) {
                    $html .= '<form action="' . route('hospitalisations.destroy', $row->uuid) . '" method="POST" class="d-inline" onsubmit="return confirm(\'Supprimer cette hospitalisation ?\')">'. csrf_field() . method_field('DELETE') . '<button type="submit" class="btn btn-sm btn-outline-danger" title="Supprimer"><i class="fa fa-trash"></i></button></form>';
                }

                return '<div class="d-flex align-items-center justify-content-center gap-1">' . $html . '</div>';
            }) //  Correction : Clôture propre de la colonne 'action'
            ->rawColumns(['etat', 'action'])
            ->make(true);
    }

    return view('application.hospitalisation.realise');
}
    // Paiement AJAX
//
//        // Créer un paiement
//        Paiement::create([
//            'hospitalisation_id' => $hospitalisation->id,
//            'montant_total'      => $request->montantTotal,
//            'montant_recu'       => $request->montantRecu,
//            'montant_restant'    => $request->montantTotal - $request->montantRecu,
//            'date_paiement'      => now(),
//        ]);
//
//        return response()->json([
//            'success' => true,
//            'message' => 'Paiement enregistré avec succès ✅'
//        ]);
//    }

    public function pdf(Hospitalisation $hospitalisation)
    {
        abort_unless(Auth::user()->can('hospitalisations.pdf'), 403, 'Accès non autorisé : vous n\'avez pas la permission d\'imprimer.');

        $hospitalisation->load(['patient', 'salle', 'lit']);

        $pdf = Pdf::loadView('application.hospitalisation.pdf', compact('hospitalisation'))
            ->setPaper('A4', 'portrait');

        return $pdf->stream("hospitalisation-{$hospitalisation->id}.pdf");
    }
    /**
     * Show the form for creating a new resource.
     */
    public function getPaiementData(Hospitalisation $hospitalisation)
    {
        $hospitalisation->load('salle');

        return response()->json([
            'date_entree' => $hospitalisation->date_entree,
            'prix_jour'   => $hospitalisation->salle->prix ?? 0,
        ]);
    }

    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        abort_unless(Auth::user()->can('hospitalisations.paiement'), 403, 'Accès non autorisé : vous n\'avez pas la permission d\'enregistrer un paiement d\'hospitalisation.');

        try {
            // 🔹 Vérifier si la caisse est ouverte
            if (!\App\Models\CaisseSession::hasOpenSession()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Votre caisse est fermée. Veuillez l\'ouvrir pour encaisser le paiement.'
                ], 403);
            }

            // 🔹 Validation des données
            $validated = $request->validate([
                'hospitalisation_id' => 'required|exists:hospitalisations,uuid',
                'dateSortie'         => 'required|date',
                'montant_total'      => 'required|numeric|min:0',
                'montant_recu'       => 'required|numeric|min:0',
            ]);

            // 🔹 Récupération de l'hospitalisation
            $hospitalisation = Hospitalisation::where('uuid', $validated['hospitalisation_id'])->firstOrFail();

            // 🔹 Vérifications métier
            if ($validated['dateSortie'] <= $hospitalisation->date_entree) {
                return response()->json([
                    'success' => false,
                    'message' => 'La date de sortie doit être après la date d’entrée'
                ], 422);
            }

            if ($validated['montant_recu'] > $validated['montant_total']) {
                return response()->json([
                    'success' => false,
                    'message' => 'Le montant reçu ne peut pas être supérieur au montant total'
                ], 422);
            }

            // 🔹 Calcul du montant restant
            $montantRestant = $validated['montant_total'] - $validated['montant_recu'];

            // 🔹 Enregistrement du paiement
            $paiement = Paiement::create([
                'hospitalisation_id' => $validated['hospitalisation_id'],
                'date_sortie'        => $validated['dateSortie'],
                'montant_total'      => $validated['montant_total'],
                'montant_recu'       => $validated['montant_recu'],
                'montant_restant'    => $montantRestant,
                'statut'             => $montantRestant > 0 ? 'partiel' : 'payé',
                'user_id'            => Auth::id(),
            ]);

            // Mise à jour de l'état de l'hospitalisation et libération du lit
            $hospitalisation->update([
                'etat'      => 'terminé',
                'date_sortie' => $validated['dateSortie'],
            ]);

            if ($hospitalisation->lit_id) {
                \App\Models\Lit::where('id', $hospitalisation->lit_id)->update(['statut' => 'Libre']);
            }

            // 🔹 Enregistrement dans la caisse
            if ($validated['montant_recu'] > 0) {
                \App\Models\CaisseSession::enregistrerMouvement(
                    $validated['montant_recu'],
                    'Paiement Hospitalisation #' . $hospitalisation->id . ' (Patient: ' . ($hospitalisation->consultation->patient->nom ?? $hospitalisation->patient->nom ?? 'Inconnu') . ')',
                    'entree',
                    $paiement
                );
            }

            // 🔹 Retour JSON pour AJAX
            return response()->json([
                'success' => true,
                'message' => 'Paiement enregistré avec succès.',
                'data'    => $paiement,
            ]);

        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur de validation',
                'errors'  => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de l\'enregistrement : ' . $e->getMessage()
            ], 500);
        }
    }



    /**
     * Display the specified resource.
     */
    public function show(Hospitalisation $hospitalisation)
    {
        abort_unless(Auth::user()->can('hospitalisations.view'), 403, 'Accès non autorisé : vous n\'avez pas la permission de voir les hospitalisations.');

        $hospitalisation->load([
            'consultation.patient',
            'service',
            'salle',
            'lit',
            'paiements'
        ]);

        $montant_total   = $hospitalisation->paiements->sum('montant_total');
        $montant_recu    = $hospitalisation->paiements->sum('montant_recu');
        $montant_restant = $montant_total - $montant_recu;

        return view('application.hospitalisation.show', compact(
            'hospitalisation',
            'montant_total',
            'montant_recu',
            'montant_restant'
        ));
    }

    /**
     * Générer la facture PDF
     */
    public function generatePDF(Hospitalisation $hospitalisation)
    {
        $hospitalisation->load([
            'consultation.patient',
            'service',
            'salle',
            'lit',
            'paiements'
        ]);

        $montant_total   = $hospitalisation->paiements->sum('montant_total');
        $montant_recu    = $hospitalisation->paiements->sum('montant_recu');
        $montant_restant = $montant_total - $montant_recu;

        $pdf = PDF::loadView('application.hospitalisation.pdf', compact(
            'hospitalisation',
            'montant_total',
            'montant_recu',
            'montant_restant'
        ));

        $fileName = 'Facture_Hospitalisation_' . $hospitalisation->id . '.pdf';
        return $pdf->download($fileName);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Hospitalisation $hospitalisation)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Hospitalisation $hospitalisation)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Hospitalisation $hospitalisation)
    {
        abort_unless(Auth::user()->can('hospitalisations.delete'), 403, 'Accès non autorisé : vous n\'avez pas la permission de supprimer une hospitalisation.');
        //
    }
}
