<?php

use App\Http\Controllers\CommandeController;
use App\Http\Controllers\ConfigurationController;
use App\Http\Controllers\ConsultationController;
use App\Http\Controllers\ExamenController;
use App\Http\Controllers\FamilleController;
use App\Http\Controllers\FournisseurController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\HospitalisationController;
use App\Http\Controllers\LitController;
use App\Http\Controllers\MaladieController;
use App\Http\Controllers\MedicamentController;
use App\Http\Controllers\OrdonnanceController;
use App\Http\Controllers\PaiementCommandeController;
use App\Http\Controllers\PaiementController;
use App\Http\Controllers\PatientController;
use App\Http\Controllers\PrescriptionExamenController;
use App\Http\Controllers\PrestationController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ReceptionController;
use App\Http\Controllers\RendezvousController;
use App\Http\Controllers\ResultatExamenController;
use App\Http\Controllers\SalleController;
use App\Http\Controllers\ServiceMedicalController;
use App\Http\Controllers\SuiviController;
use App\Http\Controllers\SymptomeController;
use App\Http\Controllers\TicketController;
use App\Http\Controllers\UniteController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AssuranceController;
use App\Http\Controllers\RolePermissionController;
use Illuminate\Support\Facades\Route;

// Quand on arrive sur la racine "/", on redirige vers le login
Route::get('/', function () {
    return redirect()->route('login');
});

// Page d'accueil après connexion

// Routes protégées par authentification
Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [HomeController::class, 'index'])->name('dashboard');
    Route::get('/', [HomeController::class, 'index'])->name('home');
    Route::post('/exercice/set', [\App\Http\Controllers\ExerciceController::class, 'setYear'])->name('exercice.set');
    Route::get('/parametre', [ConfigurationController::class, 'index'])->name('configuration');
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    Route::resource('/services', ServiceMedicalController::class);
    Route::resource('prestations', PrestationController::class);
    Route::resource('lits', LitController::class)->except(['show']);
    Route::resource('salles', SalleController::class);
    Route::resource('examens', ExamenController::class)->except(['show']);
    Route::resource('prescriptions', PrescriptionExamenController::class);
    Route::resource('reponses', ResultatExamenController::class);
    Route::get('reponses/{id}/create', [ResultatExamenController::class,'reponse'])->name('reponse.create');
    Route::resource('unites', UniteController::class)->except(['create']);
    Route::resource('familles', FamilleController::class)->except(['create']);
    Route::resource('maladies', MaladieController::class)->except(['create']);
    Route::resource('symptomes', SymptomeController::class)->except(['create']);
    Route::middleware('caisse.ouverte')->group(function() {
        Route::get('tickets/create', [TicketController::class, 'create'])->name('tickets.create');
        Route::post('tickets', [TicketController::class, 'store'])->name('tickets.store');
    });
    Route::resource('tickets', TicketController::class)->except(['create', 'store']);
    Route::get('/patients/search', [PatientController::class, 'search'])->name('patients.search');
    Route::resource('consultations', ConsultationController::class);
    Route::get('liste-attente', [ConsultationController::class, 'listeAttente'])->name('liste.attente');
    Route::resource('suivis', SuiviController::class);
    Route::resource('assurances', AssuranceController::class);

//    Route::get('suivis/create', [SuiviController::class, 'create'])->name('suivis.create');
// Route pour créer un suivi depuis une consultation
    Route::get('consultations/{consultation}/suivis/create', [SuiviController::class, 'create'])
        ->name('consultations.suivi.create');

// Stocker le suivi depuis la consultation
//    Route::post('suivis/{consultation}/suivis', [SuiviController::class, 'store'])
//        ->name('suivi.store');

    Route::get('/rendezvous/data', [RendezvousController::class, 'getData'])->name('rendezvous.data');
    Route::get('/rendezvous/disponible', [RendezvousController::class, 'disponible'])->name('rendezvous.disponible');
    Route::get('/rendezvous/annuler', [RendezvousController::class, 'annuler'])->name('rendezvous.annuler');
    Route::resource('rendezvous', RendezvousController::class)->except(['create']);
    Route::post('rendezvous/{rendezvous}/marquer-realise', [RendezvousController::class, 'marquerRealise'])
        ->name('rendezvous.marquerRealise');
    Route::resource('ordonnances', OrdonnanceController::class);
    Route::get('ordonnances/{ordonnance}/pdf', [OrdonnanceController::class, 'pdf'])->name('ordonnances.pdf');
    Route::get('paiement/{ordonnance}/ordonnance', [OrdonnanceController::class, 'paiementForm'])
        ->name('ordonnances.paiement');
    Route::post('/payer/{ordonnance}/ordonnance', [OrdonnanceController::class, 'payer']) ->name('ordonnances.payer')->middleware('caisse.ouverte');
    Route::get('/ordonnance/lespayer', [OrdonnanceController::class, 'lespayer'])->name('ordonnances.lespayer');

    Route::resource('hospitalisations', HospitalisationController::class);
    Route::post('/paiements/hospitalisation', [PaiementController::class, 'store'])
        ->name('paiements.hospitalisation')->middleware('caisse.ouverte');

    Route::get('/hospitalisations/{hospitalisation}/pdf', [HospitalisationController::class, 'generatePDF'])->name('hospitalisations.pdf');
    Route::get('/paiement/{hospitalisation}/hospitalisations', [HospitalisationController::class, 'getPaiementData'])
        ->name('hospitalisations.paiement.data');
    Route::get('/hospitalisation/realise', [HospitalisationController::class, 'hopialisationrealise'])
        ->name('hospitalisations.realise');

    Route::resource('fournisseurs', FournisseurController::class);
    Route::resource('medicaments', MedicamentController::class);
    Route::resource('commandes', CommandeController::class);
    Route::post('/commandes/panier/ajouter', [CommandeController::class, 'ajouterAuPanier'])->name('commandes.panier.ajouter');
    Route::post('/commandes/panier/bulk-ajouter', [CommandeController::class, 'bulkAjouterAuPanier'])->name('commandes.panier.bulk-ajouter');
    Route::post('/commandes/panier/modifier', [CommandeController::class, 'modifierPanier'])->name('commandes.panier.modifier');
    Route::post('/commandes/panier/supprimer', [CommandeController::class, 'supprimerDuPanier'])->name('commandes.panier.supprimer');
    Route::get('/commandes/{id}/pdf', [CommandeController::class, 'pdf'])->name('commandes.pdf');

// Supprimer un médicament du panier (AJAX)
    Route::get('/consultations/{consultation}/print', [ConsultationController::class, 'print'])->name('consultations.print');

// Vider le panier
    Route::post('/commandes/panier/vider', [CommandeController::class, 'viderPanier'])->name('commandes.panier.vider');

    Route::get('/tickets/{ticket}/print', [TicketController::class, 'print'])->name('tickets.print');

    Route::resource('receptions', ReceptionController::class);

//    Route::get('/receptions', [ReceptionController::class, 'index'])->name('receptions.index');
//    Route::get('/receptions/create', [ReceptionController::class, 'create'])->name('receptions.create');

    Route::get('/commandes/{id}/produits', [ReceptionController::class, 'getProduits']); // pour AJAX

//    Route::post('/receptions', [ReceptionController::class, 'store'])->name('receptions.store');

    Route::get('/salle/{salleId}/lits-libres', [SalleController::class, 'litsLibres'])->name('salles.litsLibres');


// Route pour récupérer les médicaments d'une commande (Ajax)
    Route::get('commandes/{commande}/medicaments', [CommandeController::class,'medicaments'])->name('commandes.medicaments');

    Route::prefix('paiementscommande')->group(function () {
        Route::get('/dashboard', [PaiementCommandeController::class, 'dashboard'])->name('paiementscommande.dashboard');
        Route::get('/create', [PaiementCommandeController::class, 'create'])->name('paiementscommande.create')->middleware('caisse.ouverte');
        Route::post('/store', [PaiementCommandeController::class, 'store'])->name('paiementscommande.store')->middleware('caisse.ouverte');
        Route::get('/history/{commande}', [PaiementCommandeController::class, 'history'])->name('paiementscommande.history');
        Route::delete('/{id}', [PaiementCommandeController::class, 'destroy'])->name('paiementscommande.destroy');
    });

    // Caisse Globale
    // Routes Caisse
    Route::get('/caisse', [\App\Http\Controllers\CaisseController::class, 'index'])->name('caisse.index');
    Route::get('/caisse/ma-session', [\App\Http\Controllers\CaisseController::class, 'mySession'])->name('caisse.my_session');
    Route::get('/caisse/ouvrir', [\App\Http\Controllers\CaisseController::class, 'open'])->name('caisse.open');
    Route::post('/caisse/ouvrir', [\App\Http\Controllers\CaisseController::class, 'storeOpen'])->name('caisse.storeOpen');
    Route::get('/caisse/cloturer', [\App\Http\Controllers\CaisseController::class, 'close'])->name('caisse.close');
    Route::post('/caisse/cloturer', [\App\Http\Controllers\CaisseController::class, 'storeClose'])->name('caisse.storeClose');

    // Transferts
    Route::resource('transferts', \App\Http\Controllers\TransfertController::class)->only(['index', 'store', 'destroy']);

    // Dossiers Patients
    Route::resource('patients', PatientController::class);
    Route::get('/patients/{patient}/dossier', [PatientController::class, 'print'])->name('patients.medicales');
    Route::get('/users', [UserController::class, 'index'])->name('users.index');
    Route::get('/users/create', [UserController::class, 'create'])->name('users.create');
    // Routes statiques déclarées avant {user} pour éviter le conflit de wildcard
    Route::get('/users/datatable', [UserController::class, 'datatable'])->name('users.datatable');
    Route::get('/users/data', [UserController::class, 'getData'])->name('users.data');
    Route::post('/users', [UserController::class, 'store'])->name('users.store');
    Route::get('/users/{user}', [UserController::class, 'show'])->name('users.show');
    Route::get('/users/{user}/edit', [UserController::class, 'edit'])->name('users.edit');
    Route::put('/users/{user}', [UserController::class, 'update'])->name('users.update');
    Route::post('/users/{user}/status', [UserController::class, 'updateStatus'])->name('users.status');
    Route::delete('/users/{user}', [UserController::class, 'destroy'])->name('users.destroy');

    // Routes spécifiques pour les médecins
    Route::get('/medecins', [UserController::class, 'medecins'])->name('medecins.index');
    // Modules demandés (Infectiologie & Traitements)
    Route::prefix('infectiologie')->group(function () {
        Route::get('/pathologies', [\App\Http\Controllers\InfectiologieController::class, 'pathologies'])->name('infectiologie.pathologies');
        Route::get('/pathogenes', [\App\Http\Controllers\InfectiologieController::class, 'pathogenes'])->name('infectiologie.pathogenes');
        Route::get('/pathologies-api', function() {
            return response()->json(\App\Models\Maladie::all());
        })->name('infectiologie.pathologies.api');
        Route::get('/statistiques', [\App\Http\Controllers\InfectiologieController::class, 'statistiques'])->name('infectiologie.statistiques');
        Route::get('/protocoles', [\App\Http\Controllers\InfectiologieController::class, 'protocoles'])->name('infectiologie.protocoles');
        Route::get('/protocoles/{protocole}', [\App\Http\Controllers\InfectiologieController::class, 'showProtocole'])->name('infectiologie.protocoles.show');
        Route::post('/protocoles', [\App\Http\Controllers\InfectiologieController::class, 'storeProtocole'])->name('infectiologie.protocoles.store');
        Route::delete('/protocoles/{protocole}', [\App\Http\Controllers\InfectiologieController::class, 'destroyProtocole'])->name('infectiologie.protocoles.destroy');

        Route::get('/aide-prescription', [\App\Http\Controllers\InfectiologieController::class, 'aidePrescription'])->name('infectiologie.aide_prescription');
        Route::get('/suivi-traitements', [\App\Http\Controllers\InfectiologieController::class, 'suivi'])->name('infectiologie.suivi');
        Route::get('/api/protocoles/{maladie}', [\App\Http\Controllers\InfectiologieController::class, 'getProtocole'])->name('infectiologie.get_protocole');
        Route::get('/api/medicaments-list', [\App\Http\Controllers\InfectiologieController::class, 'getMedicaments'])->name('api.medicaments.list');
    });

    // 🔹 Diagnostic Intelligent
    Route::get('/api/clinical/interrogation', [\App\Http\Controllers\DiagnosticController::class, 'interrogate'])->name('clinical.interrogation');
    Route::get('/api/clinical/suggest-symptoms', [\App\Http\Controllers\DiagnosticController::class, 'suggestFollowUp'])->name('clinical.suggest_symptoms');

    // 🔹 Suivi de Traitement (Evolution clinique)
    Route::post('/suivi-traitements-store', [\App\Http\Controllers\SuiviTraitementController::class, 'store'])->name('suivi.store');
    Route::get('/consultation/{id}/suivis', [\App\Http\Controllers\SuiviTraitementController::class, 'getByConsultation'])->name('suivi.get');

    // 🔹 Maternité (Grossesse & CPN)
    Route::prefix('maternity')->name('maternity.')->group(function () {
        Route::get('/', [\App\Http\Controllers\MaternityController::class, 'index'])->name('index');
        Route::get('/create', [\App\Http\Controllers\MaternityController::class, 'create'])->name('create');
        Route::post('/store', [\App\Http\Controllers\MaternityController::class, 'store'])->name('store');
        Route::get('/{grossesse}', [\App\Http\Controllers\MaternityController::class, 'show'])->name('show');
        Route::post('/cpn', [\App\Http\Controllers\MaternityController::class, 'storeCpn'])->name('cpn.store');
        Route::post('/{grossesse}/close', [\App\Http\Controllers\MaternityController::class, 'close'])->name('close');
    });

});

// Routes pour la gestion des rôles et permissions
Route::middleware(['auth'])->prefix('admin')->name('admin.')->group(function () {
    
    // Gestion des rôles
    Route::resource('roles', RolePermissionController::class);
    
    // Gestion des permissions des rôles
    Route::put('roles/{role}/permissions', [RolePermissionController::class, 'updatePermissions'])
        ->name('roles.permissions.update');
    
    // Gestion des permissions globales
    Route::get('permissions', [RolePermissionController::class, 'permissions'])
        ->name('permissions.index');
    
    // Gestion des permissions des utilisateurs (API)
    Route::get('users/{user}/permissions', [RolePermissionController::class, 'getUserPermissions'])
        ->name('users.permissions');
    Route::post('users/{user}/permissions', [RolePermissionController::class, 'assignUserPermissions'])
        ->name('users.permissions.assign');
});

// Auth routes générées par Breeze ou Jetstream
require __DIR__.'/auth.php';
